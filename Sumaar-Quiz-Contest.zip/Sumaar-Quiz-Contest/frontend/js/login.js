const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", async function (e) {

    e.preventDefault();

    const loginData = {

        email: document.getElementById("email").value,
        password: document.getElementById("password").value

    };

    try {

        const response = await fetch(
            "http://localhost:8080/api/auth/login",
            {

                method: "POST",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify(loginData)

            });

        if (response.ok) {

            const user = await response.json();

            sessionStorage.setItem("user", JSON.stringify(user));

            window.location.href = "dashboard.html";

        }

        else {

            alert("Invalid Email or Password");

        }

    }

    catch (error) {

        console.log(error);

        alert("Server Error");

    }

});