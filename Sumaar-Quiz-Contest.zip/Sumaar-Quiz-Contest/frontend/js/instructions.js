const user = JSON.parse(sessionStorage.getItem("user"));

if (!user) {

    window.location.href = "login.html";

}

document.getElementById("studentName").innerHTML =
    user.fullName || "-";

document.getElementById("candidateName").innerHTML =
    user.fullName || "-";

document.getElementById("candidateCollege").innerHTML =
    user.college || "-";

document.getElementById("candidateDept").innerHTML =
    user.department || "-";

document.getElementById("candidateAssessment").innerHTML =
    user.assessmentCategory || "-";
// Agreement Validation
const checkbox = document.getElementById("agreeCheck");
const button = document.getElementById("beginBtn");

// checkbox.addEventListener("change", () => {

//     if (checkbox.checked) {

//         button.disabled = false;
//         button.classList.add("enabled");

//     } else {

//         button.disabled = true;
//         button.classList.remove("enabled");

//     }

// });
checkbox.addEventListener("change", () => {

    console.log("Checkbox changed");

    console.log(checkbox.checked);

    button.disabled = !checkbox.checked;

});
// Start Assessment
button.addEventListener("click", () => {

    if (checkbox.checked) {

        window.location.href = "assessment.html";

    }

});

