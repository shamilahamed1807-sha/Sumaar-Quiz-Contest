const user = JSON.parse(sessionStorage.getItem("user"));

if (!user) {

    window.location.href = "login.html";

}

// --------------------------
// Get Scores
// --------------------------

const round1 = Number(sessionStorage.getItem("round1Score")) || 0;
const round2 = Number(sessionStorage.getItem("round2Score")) || 0;
const round3 = Number(sessionStorage.getItem("round3Score")) || 0;

const total = round1 + round2 + round3;

const accuracy = Math.round((total / 30) * 100);

// --------------------------
// Overall
// --------------------------

document.getElementById("overallScore").innerHTML =
total + " / 30";

document.getElementById("overallAccuracy").innerHTML =
accuracy + "%";

if (accuracy >= 50) {

    document.getElementById("overallStatus").innerHTML =
    "PASS";

}
else{

    document.getElementById("overallStatus").innerHTML =
    "FAIL";

}

// --------------------------
// Rank
// --------------------------

let rank = "D";

if(accuracy>=90){

    rank="A+";

}
else if(accuracy>=80){

    rank="A";

}
else if(accuracy>=70){

    rank="B";

}
else if(accuracy>=60){

    rank="C";

}
else{

    rank="D";

}

document.getElementById("overallRank").innerHTML=rank;

// --------------------------
// Round Table
// --------------------------

const rows=document.querySelectorAll("tbody tr");

rows[0].cells[2].innerHTML=round1;
rows[0].cells[3].innerHTML=round1+"/10";
rows[0].cells[4].innerHTML=
round1>=5?"Passed":"Failed";

rows[1].cells[2].innerHTML=round2;
rows[1].cells[3].innerHTML=round2+"/10";
rows[1].cells[4].innerHTML=
round2>=5?"Passed":"Failed";

rows[2].cells[2].innerHTML=round3;
rows[2].cells[3].innerHTML=round3+"/10";
rows[2].cells[4].innerHTML=
round3>=5?"Passed":"Failed";