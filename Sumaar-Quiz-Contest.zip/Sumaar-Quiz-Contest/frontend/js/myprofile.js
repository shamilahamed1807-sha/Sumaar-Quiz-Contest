const user = JSON.parse(sessionStorage.getItem("user"));

if (!user) {

    window.location.href = "login.html";

}

document.getElementById("profileName").innerHTML = user.fullName;
document.getElementById("profileEmail").innerHTML = user.email;

document.getElementById("fullNameValue").value = user.fullName;
document.getElementById("emailValue").value = user.email;

document.getElementById("mobileValue").value = user.mobile || "";
document.getElementById("genderValue").value = user.gender || "";

document.getElementById("collegeValue").value = user.college || "";
document.getElementById("departmentValue").value = user.department || "";
document.getElementById("yearValue").value = user.year || "";
document.getElementById("sectionValue").value = user.section || "";
const editBtn = document.getElementById("editBtn");
const saveBtn = document.getElementById("saveBtn");
const cancelBtn = document.getElementById("cancelBtn");

const fields = [

    "fullNameValue",
    "emailValue",
    "mobileValue",
    "genderValue",
    "collegeValue",
    "departmentValue",
    "yearValue",
    "sectionValue",
    "categoryValue",
    "languageValue",
    "difficultyValue"

];

editBtn.onclick = () => {

    fields.forEach(id => {

        const input = document.getElementById(id);

        if(input){

            input.disabled = false;

        }

    });

    editBtn.style.display = "none";

    saveBtn.style.display = "inline-block";

    cancelBtn.style.display = "inline-block";

};

// saveBtn.onclick = () => {

//     fields.forEach(id => {

//         const input = document.getElementById(id);

//         if(input){

//             input.disabled = true;

//         }

//     });

//     editBtn.style.display = "inline-block";

//     saveBtn.style.display = "none";

//     cancelBtn.style.display = "none";

//     alert("Profile Updated Successfully!");

// };

// cancelBtn.onclick = () => {

//     location.reload();

// };

saveBtn.onclick = () => {

    // Get latest user object
    let user = JSON.parse(sessionStorage.getItem("user"));

    // Update values from inputs
    user.fullName = document.getElementById("fullNameValue").value;
    user.email = document.getElementById("emailValue").value;
    user.mobile = document.getElementById("mobileValue").value;
    user.gender = document.getElementById("genderValue").value;
    user.college = document.getElementById("collegeValue").value;
    user.department = document.getElementById("departmentValue").value;
    user.year = document.getElementById("yearValue").value;
    user.section = document.getElementById("sectionValue").value;
    user.assessmentCategory = document.getElementById("categoryValue").value;
    user.language = document.getElementById("languageValue").value;
    user.difficulty = document.getElementById("difficultyValue").value;

    // Save updated data
    sessionStorage.setItem("user", JSON.stringify(user));

    // Disable all fields again
    fields.forEach(id => {

        const input = document.getElementById(id);

        if(input){

            input.disabled = true;

        }

    });

    // Update heading immediately
    document.getElementById("profileName").innerHTML = user.fullName;
    document.getElementById("fullNameValue").value = user.fullName;

    editBtn.style.display = "inline-block";
    saveBtn.style.display = "none";
    cancelBtn.style.display = "none";

    alert("Profile Updated Successfully!");

};