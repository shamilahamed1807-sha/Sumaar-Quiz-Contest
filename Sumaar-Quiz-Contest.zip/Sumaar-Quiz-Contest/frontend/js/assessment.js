// ---------------------------
// Sample Questions
// ---------------------------

const questions = [

{
question:"Which keyword is used to inherit a class in Java?",
options:["implements","extends","inherit","super"],
correct:1
},

{
question:"Which language runs inside a web browser?",
options:["Java","Python","JavaScript","C"],
correct:2
},

{
question:"HTML stands for?",
options:[
"Hyper Text Markup Language",
"High Text Machine Language",
"Hyper Transfer Markup Language",
"Home Tool Markup Language"
],
correct:0
},

{
question:"CSS is used for?",
options:[
"Database",
"Styling",
"Compiler",
"Programming"
],
correct:1
},

{
question:"Which company developed Java?",
options:[
"Microsoft",
"Sun Microsystems",
"Google",
"IBM"
],
correct:1
},

{
question:"Which symbol is used for comments in Java?",
options:[
"//",
"#",
"<!-- -->",
"**"
],
correct:0
},

{
question:"Which keyword creates an object?",
options:[
"class",
"object",
"new",
"create"
],
correct:2
},

{
question:"Java is a ____ language.",
options:[
"Markup",
"Programming",
"Scripting",
"Query"
],
correct:1
},

{
question:"JVM means?",
options:[
"Java Variable Method",
"Java Virtual Machine",
"Java Verified Module",
"Java Version Manager"
],
correct:1
},

{
question:"Which collection stores unique values?",
options:[
"List",
"Array",
"Set",
"Queue"
],
correct:2
}

];

// ---------------------------

let currentQuestion = 0;

let answers = new Array(questions.length).fill(null);

// ---------------------------

const questionText=document.getElementById("questionText");

const questionNo=document.getElementById("questionNo");

const options=document.querySelector(".options");

const progress=document.getElementById("progressFill");

const palette=document.querySelectorAll(".palette-btn");

// ---------------------------

function loadQuestion(){

questionNo.innerHTML="Question "+(currentQuestion+1);

document.getElementById("headerProgress").innerHTML =
"Question " + (currentQuestion + 1) + " of " + questions.length;

document.getElementById("questionProgress").innerHTML =
"Question " + (currentQuestion + 1) + " of " + questions.length;

questionText.innerHTML=questions[currentQuestion].question;

options.innerHTML="";

questions[currentQuestion].options.forEach((opt,index)=>{

const label=document.createElement("label");

label.className="option";

label.innerHTML=`
<input type="radio"
name="answer"
value="${index}"
${answers[currentQuestion]==index?"checked":""}>
<span>${opt}</span>
`;

label.onclick=()=>{

answers[currentQuestion]=index;

palette[currentQuestion].classList.add("answered");

};

options.appendChild(label);

});

progress.style.width=((currentQuestion+1)/questions.length)*100+"%";

palette.forEach(btn=>btn.classList.remove("active"));

palette[currentQuestion].classList.add("active");

}

// ---------------------------

document.querySelector(".btn-primary").onclick=()=>{

if(currentQuestion<questions.length-1){

currentQuestion++;

loadQuestion();

}else{

let score = 0;

answers.forEach((ans, index) => {
    if (ans === questions[index].correct) {
        score++;
    }
});

sessionStorage.setItem("round1Score", score);
sessionStorage.setItem("round1Answers", JSON.stringify(answers));

alert("Round 1 Completed!");

window.location.href = "round2.html";

}

};

// ---------------------------

document.querySelector(".btn-secondary").onclick=()=>{

if(currentQuestion>0){

currentQuestion--;

loadQuestion();

}

};

// ---------------------------

palette.forEach((btn,index)=>{

btn.onclick=()=>{

currentQuestion=index;

loadQuestion();

};

});

// ---------------------------
// TIMER
// ---------------------------
let time=1800;
function startTimer(){
const timer=document.getElementById("timer");
setInterval(()=>{
let min=Math.floor(time/60);
let sec=time%60;
timer.innerHTML=
String(min).padStart(2,"0")+":"+
String(sec).padStart(2,"0");
time--;
if(time<0){
alert("Time Up!");
window.location.href="round2.html";
}
},1000);
}
loadQuestion();
startTimer();