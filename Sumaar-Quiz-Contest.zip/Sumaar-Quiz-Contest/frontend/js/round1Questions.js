const round1Questions = [

{
question:"Which keyword is used to inherit a class in Java?",
options:["implements","extends","inherit","super"],
correct:1
},

{
question:"Which language runs inside a web browser?",
options:["Java","Python","JavaScript","C"],
correct:2
},

{
question:"HTML stands for?",
options:[
"Hyper Text Markup Language",
"High Text Machine Language",
"Hyper Transfer Markup Language",
"Home Tool Markup Language"
],
correct:0
},

{
question:"CSS is used for?",
options:[
"Database",
"Styling",
"Compiler",
"Programming"
],
correct:1
},

{
question:"Which company developed Java?",
options:[
"Microsoft",
"Sun Microsystems",
"Google",
"IBM"
],
correct:1
},

{
question:"Which symbol is used for comments in Java?",
options:[
"//",
"#",
"<!-- -->",
"**"
],
correct:0
},

{
question:"Which keyword creates an object?",
options:[
"class",
"object",
"new",
"create"
],
correct:2
},

{
question:"Java is a ____ language.",
options:[
"Markup",
"Programming",
"Scripting",
"Query"
],
correct:1
},

{
question:"JVM means?",
options:[
"Java Variable Method",
"Java Virtual Machine",
"Java Verified Module",
"Java Version Manager"
],
correct:1
},

{
question:"Which collection stores unique values?",
options:[
"List",
"Array",
"Set",
"Queue"
],
correct:2
}

];