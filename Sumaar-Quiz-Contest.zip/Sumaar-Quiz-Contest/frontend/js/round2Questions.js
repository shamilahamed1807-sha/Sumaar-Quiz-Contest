const round2Questions = [

{
question:"What is the output of 5 + 2 * 3 ?",
options:["21","11","16","15"],
correct:1
},

{
question:"Which Java collection stores unique values?",
options:["ArrayList","HashSet","Vector","LinkedList"],
correct:1
},

{
question:"Which keyword terminates a loop?",
options:["continue","break","stop","exit"],
correct:1
},

{
question:"Which method is the entry point of Java?",
options:["run()","main()","execute()","start()"],
correct:1
},

{
question:"Which data type stores decimal numbers?",
options:["int","char","double","boolean"],
correct:2
},

{
question:"Which loop executes at least once?",
options:["for","while","do while","foreach"],
correct:2
},

{
question:"Which operator checks equality?",
options:["=","==",":=","!="],
correct:1
},

{
question:"Which keyword is used to create an object?",
options:["class","new","object","create"],
correct:1
},

{
question:"Which is NOT an OOP principle?",
options:["Inheritance","Compilation","Polymorphism","Encapsulation"],
correct:1
},

{
question:"Which access modifier is the most restrictive?",
options:["public","protected","default","private"],
correct:3
}

];