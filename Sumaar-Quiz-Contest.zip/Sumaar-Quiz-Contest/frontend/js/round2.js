// ---------------------------
// Sample Questions
// ---------------------------
const questions = [

{
question:"What is the output of 5 + 2 * 3 ?",
options:["21","11","16","15"],
correct:1
},

{
question:"Which Java collection stores unique values?",
options:["ArrayList","HashSet","Vector","LinkedList"],
correct:1
},

{
question:"Which keyword terminates a loop?",
options:["continue","break","stop","exit"],
correct:1
},

{
question:"Which method is the entry point of Java?",
options:["run()","main()","execute()","start()"],
correct:1
},

{
question:"Which data type stores decimal numbers?",
options:["int","char","double","boolean"],
correct:2
},

{
question:"Which loop executes at least once?",
options:["for","while","do while","foreach"],
correct:2
},

{
question:"Which operator checks equality?",
options:["=","==",":=","!="],
correct:1
},

{
question:"Which keyword is used to create an object?",
options:["class","new","object","create"],
correct:1
},

{
question:"Which is NOT an OOP principle?",
options:["Inheritance","Compilation","Polymorphism","Encapsulation"],
correct:1
},

{
question:"Which access modifier is the most restrictive?",
options:["public","protected","default","private"],
correct:3
}

];
// ---------------------------

let currentQuestion = 0;

let answers = new Array(questions.length).fill(null);

// ---------------------------

const questionText=document.getElementById("questionText");

const questionNo=document.getElementById("questionNo");

const options=document.querySelector(".options");

const progress=document.getElementById("progressFill");

const palette=document.querySelectorAll(".palette-btn");

// ---------------------------

function loadQuestion(){

questionNo.innerHTML="Question "+(currentQuestion+1);

document.getElementById("headerProgress").innerHTML =
"Question " + (currentQuestion + 1) + " of " + questions.length;

document.getElementById("questionProgress").innerHTML =
"Question " + (currentQuestion + 1) + " of " + questions.length;

questionText.innerHTML=questions[currentQuestion].question;

options.innerHTML="";

questions[currentQuestion].options.forEach((opt,index)=>{

const label=document.createElement("label");

label.className="option";

label.innerHTML=`
<input type="radio"
name="answer"
value="${index}"
${answers[currentQuestion]==index?"checked":""}>
<span>${opt}</span>
`;

label.onclick=()=>{

answers[currentQuestion]=index;

palette[currentQuestion].classList.add("answered");

};

options.appendChild(label);

});

progress.style.width=((currentQuestion+1)/questions.length)*100+"%";

palette.forEach(btn=>btn.classList.remove("active"));

palette[currentQuestion].classList.add("active");

}

// ---------------------------

document.querySelector(".btn-primary").onclick=()=>{

if(currentQuestion<questions.length-1){

currentQuestion++;

loadQuestion();

}else{

let score = 0;

answers.forEach((ans,index)=>{

    if(ans===questions[index].correct){
        score++;
    }

});

sessionStorage.setItem("round2Score",score);

sessionStorage.setItem(
    "round2Answers",
    JSON.stringify(answers)
);

alert("Round 2 Completed!");

window.location.href="round3.html";

}

};

// ---------------------------

document.querySelector(".btn-secondary").onclick=()=>{

if(currentQuestion>0){

currentQuestion--;

loadQuestion();

}

};

// ---------------------------

palette.forEach((btn,index)=>{

btn.onclick=()=>{

currentQuestion=index;

loadQuestion();

};

});

// ---------------------------
// TIMER
// ---------------------------
let time=1800;
function startTimer(){
const timer=document.getElementById("timer");
setInterval(()=>{
let min=Math.floor(time/60);
let sec=time%60;
timer.innerHTML=
String(min).padStart(2,"0")+":"+
String(sec).padStart(2,"0");
time--;
if(time<0){
alert("Time Up!");
window.location.href="round3.html";
}
},1000);
}
loadQuestion();
startTimer();