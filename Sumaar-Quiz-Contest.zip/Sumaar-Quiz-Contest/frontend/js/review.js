const user = JSON.parse(sessionStorage.getItem("user"));

if (!user) {
    window.location.href = "login.html";
}
console.log("Round 1 Questions:", round1Questions);
console.log("Round 2 Questions:", round2Questions);
console.log("Round 3 Questions:", round3Questions);

// -----------------------------
// Get User Answers
// -----------------------------

const round1Answers = JSON.parse(sessionStorage.getItem("round1Answers")) || [];
const round2Answers = JSON.parse(sessionStorage.getItem("round2Answers")) || [];
const round3Answers = JSON.parse(sessionStorage.getItem("round3Answers")) || [];

console.log("Round 1 Answers:", round1Answers);
console.log("Round 2 Answers:", round2Answers);
console.log("Round 3 Answers:", round3Answers);
// -----------------------------
// Merge Questions
// -----------------------------

const allRounds = [
    {
        name: "Round 1",
        questions: round1Questions,
        answers: round1Answers
    },
    {
        name: "Round 2",
        questions: round2Questions,
        answers: round2Answers
    },
    {
        name: "Round 3",
        questions: round3Questions,
        answers: round3Answers
    }
];

// -----------------------------

let wrongCount = 0;
let correctCount = 0;

const container = document.getElementById("reviewContainer");

// -----------------------------

allRounds.forEach(round => {

    let roundHTML = "";

    round.questions.forEach((q, index) => {

        const userAnswer = round.answers[index];

        if (userAnswer == q.correct) {

            correctCount++;

        } else {

            wrongCount++;

            roundHTML += `

            <div class="card" style="margin-bottom:20px;">

                <h3 style="color:#e53935;">
                    ❌ ${round.name} - Question ${index + 1}
                </h3>

                <br>

                <p><strong>Question</strong></p>

                <p>${q.question}</p>

                <br>

                <p><strong>Your Answer</strong></p>

                <p style="color:red;">
                    ${
                        userAnswer == null
                        ? "Not Answered"
                        : q.options[userAnswer]
                    }
                </p>

                <br>

                <p><strong>Correct Answer</strong></p>

                <p style="color:green;">
                    ${q.options[q.correct]}
                </p>

            </div>

            `;

        }

    });

    container.innerHTML += roundHTML;

});

// -----------------------------
// Summary
// -----------------------------

document.getElementById("wrongCount").innerHTML = wrongCount;

document.getElementById("correctCount").innerHTML = correctCount;

const accuracy = Math.round((correctCount / 30) * 100);

document.getElementById("accuracy").innerHTML =
accuracy + "%";

// -----------------------------
// Perfect Score
// -----------------------------

if (wrongCount === 0) {

    container.innerHTML = `

    <div class="card">

        <h2 style="color:green;">
            🎉 Congratulations!
        </h2>

        <br>

        <h3>

            You answered all 30 questions correctly.

        </h3>

        <br>

        <p>

            Excellent Performance!

        </p>

    </div>

    `;

}