// const user = JSON.parse(sessionStorage.getItem("user"));

// if(!user){
//     window.location.href="login.html";
// }

// document.getElementById("studentName").innerHTML =
// user.fullName;
// ---------------------------
// Sample Questions
// ---------------------------
const round3Questions = [

{
question: "What will be the output of the following Java code?\n\nint x = 5;\nSystem.out.println(x++ + ++x);",
options:[
"10",
"11",
"12",
"13"
],
correct:2
},

{
question:"Which data structure is used internally by recursion?",
options:[
"Queue",
"Heap",
"Stack",
"Linked List"
],
correct:2
},

{
question:"Which sorting algorithm has the best average-case time complexity?",
options:[
"Bubble Sort",
"Selection Sort",
"Merge Sort",
"Insertion Sort"
],
correct:2
},

{
question:"Which SQL query returns the second highest salary from an Employee table?",
options:[
"SELECT MAX(salary) FROM Employee;",
"SELECT salary FROM Employee ORDER BY salary LIMIT 1;",
"SELECT MAX(salary) FROM Employee WHERE salary < (SELECT MAX(salary) FROM Employee);",
"SELECT salary FROM Employee GROUP BY salary;"
],
correct:2
},

{
question:"Which of the following time complexities is the fastest for searching in a balanced Binary Search Tree?",
options:[
"O(n)",
"O(log n)",
"O(n log n)",
"O(1)"
],
correct:1
},

{
question:"What is the output of the following?\n\nString s = \"Java\";\nSystem.out.println(s.substring(1,3));",
options:[
"Ja",
"av",
"ava",
"Java"
],
correct:1
},

{
question:"Which HTTP status code indicates that the requested resource was not found?",
options:[
"200",
"301",
"404",
"500"
],
correct:2
},

{
question:"Which of the following is NOT an ACID property of a database transaction?",
options:[
"Atomicity",
"Consistency",
"Isolation",
"Inheritance"
],
correct:3
},

{
question:"Which traversal of a Binary Search Tree always gives elements in sorted order?",
options:[
"Preorder",
"Postorder",
"Inorder",
"Level Order"
],
correct:2
},

{
question:"Which Java Collection does NOT allow duplicate elements and maintains insertion order?",
options:[
"HashSet",
"TreeSet",
"LinkedHashSet",
"ArrayList"
],
correct:2
}

];