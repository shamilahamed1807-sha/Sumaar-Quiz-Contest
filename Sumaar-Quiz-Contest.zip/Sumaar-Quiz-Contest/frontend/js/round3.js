const user = JSON.parse(sessionStorage.getItem("user"));

if(!user){
    window.location.href="login.html";
}

document.getElementById("studentName").innerHTML =
user.fullName;
// ---------------------------
// Sample Questions
// ---------------------------
const questions = [

{
question: "What will be the output of the following Java code?\n\nint x = 5;\nSystem.out.println(x++ + ++x);",
options:[
"10",
"11",
"12",
"13"
],
correct:2
},

{
question:"Which data structure is used internally by recursion?",
options:[
"Queue",
"Heap",
"Stack",
"Linked List"
],
correct:2
},

{
question:"Which sorting algorithm has the best average-case time complexity?",
options:[
"Bubble Sort",
"Selection Sort",
"Merge Sort",
"Insertion Sort"
],
correct:2
},

{
question:"Which SQL query returns the second highest salary from an Employee table?",
options:[
"SELECT MAX(salary) FROM Employee;",
"SELECT salary FROM Employee ORDER BY salary LIMIT 1;",
"SELECT MAX(salary) FROM Employee WHERE salary < (SELECT MAX(salary) FROM Employee);",
"SELECT salary FROM Employee GROUP BY salary;"
],
correct:2
},

{
question:"Which of the following time complexities is the fastest for searching in a balanced Binary Search Tree?",
options:[
"O(n)",
"O(log n)",
"O(n log n)",
"O(1)"
],
correct:1
},

{
question:"What is the output of the following?\n\nString s = \"Java\";\nSystem.out.println(s.substring(1,3));",
options:[
"Ja",
"av",
"ava",
"Java"
],
correct:1
},

{
question:"Which HTTP status code indicates that the requested resource was not found?",
options:[
"200",
"301",
"404",
"500"
],
correct:2
},

{
question:"Which of the following is NOT an ACID property of a database transaction?",
options:[
"Atomicity",
"Consistency",
"Isolation",
"Inheritance"
],
correct:3
},

{
question:"Which traversal of a Binary Search Tree always gives elements in sorted order?",
options:[
"Preorder",
"Postorder",
"Inorder",
"Level Order"
],
correct:2
},

{
question:"Which Java Collection does NOT allow duplicate elements and maintains insertion order?",
options:[
"HashSet",
"TreeSet",
"LinkedHashSet",
"ArrayList"
],
correct:2
}

];
// ---------------------------

let currentQuestion = 0;

let answers = new Array(questions.length).fill(null);

// ---------------------------

const questionText=document.getElementById("questionText");

const questionNo=document.getElementById("questionNo");

const options=document.querySelector(".options");

const progress=document.getElementById("progressFill");

const palette=document.querySelectorAll(".palette-btn");

// ---------------------------

function loadQuestion(){

questionNo.innerHTML="Question "+(currentQuestion+1);

document.getElementById("headerProgress").innerHTML =
"Question " + (currentQuestion + 1) + " of " + questions.length;

document.getElementById("questionProgress").innerHTML =
"Question " + (currentQuestion + 1) + " of " + questions.length;

questionText.innerHTML=questions[currentQuestion].question;

options.innerHTML="";

questions[currentQuestion].options.forEach((opt,index)=>{

const label=document.createElement("label");

label.className="option";

label.innerHTML=`
<input type="radio"
name="answer"
value="${index}"
${answers[currentQuestion]==index?"checked":""}>
<span>${opt}</span>
`;

label.onclick=()=>{

answers[currentQuestion]=index;

palette[currentQuestion].classList.add("answered");

};

options.appendChild(label);

});

progress.style.width=((currentQuestion+1)/questions.length)*100+"%";

palette.forEach(btn=>btn.classList.remove("active"));

palette[currentQuestion].classList.add("active");

}

// ---------------------------

document.querySelector(".btn-primary").onclick=()=>{

if(currentQuestion<questions.length-1){

currentQuestion++;

loadQuestion();

}else{

let score = 0;

answers.forEach((ans,index)=>{

    if(ans===questions[index].correct){
        score++;
    }

});

sessionStorage.setItem("round3Score",score);

sessionStorage.setItem(
    "round3Answers",
    JSON.stringify(answers)
);

alert("Round 3 Completed!");

window.location.href="results.html";

}

};

// ---------------------------

document.querySelector(".btn-secondary").onclick=()=>{

if(currentQuestion>0){

currentQuestion--;

loadQuestion();

}

};

// ---------------------------

palette.forEach((btn,index)=>{

btn.onclick=()=>{

currentQuestion=index;

loadQuestion();

};

});

// ---------------------------
// TIMER
// ---------------------------
let time=1800;
function startTimer(){
const timer=document.getElementById("timer");
setInterval(()=>{
let min=Math.floor(time/60);
let sec=time%60;
timer.innerHTML=
String(min).padStart(2,"0")+":"+
String(sec).padStart(2,"0");
time--;
if(time<0){
alert("Time Up!");
window.location.href="results.html";
}
},1000);
}
loadQuestion();
startTimer();