// ==========================================
// PROFILE PAGE JAVASCRIPT
// ==========================================

// Steps

const step1 = document.getElementById("step1");
const step2 = document.getElementById("step2");
const step3 = document.getElementById("step3");

// Progress Bar

const progressFill = document.querySelector(".progress-fill");
const progressText = document.querySelector(".profile-progress p");

// Buttons

const next1 = document.getElementById("next1");
const next2 = document.getElementById("next2");

const previous1 = document.getElementById("previous1");
const previous2 = document.getElementById("previous2");

// ==========================================
// STEP 1 → STEP 2
// ==========================================

next1.addEventListener("click", function () {

    const fullName = document.getElementById("fullName").value.trim();
    const mobile = document.getElementById("mobile").value.trim();
    const gender = document.getElementById("gender").value;

    if (fullName === "") {
        alert("Please enter your Full Name.");
        return;
    }

    if (mobile.length !== 10) {
        alert("Please enter a valid 10-digit Mobile Number.");
        return;
    }

    if (gender === "") {
        alert("Please select your Gender.");
        return;
    }

    step1.style.display = "none";
    step2.style.display = "block";

    progressFill.style.width = "66%";
    progressText.innerHTML = "Step 2 of 3";

});

// ==========================================
// STEP 2 → STEP 1
// ==========================================

previous1.addEventListener("click", function () {

    step2.style.display = "none";
    step1.style.display = "block";

    progressFill.style.width = "33%";
    progressText.innerHTML = "Step 1 of 3";

});

// ==========================================
// STEP 2 → STEP 3
// ==========================================

next2.addEventListener("click", function () {

    const registerNo = document.getElementById("registerNo").value.trim();
    const college = document.getElementById("college").value.trim();
    const department = document.getElementById("department").value;
    const year = document.getElementById("year").value;
    const section = document.getElementById("section").value;

    if (registerNo === "") {
        alert("Please enter Register Number.");
        return;
    }

    if (college === "") {
        alert("Please enter College Name.");
        return;
    }

    if (department === "") {
        alert("Please select Department.");
        return;
    }

    if (year === "") {
        alert("Please select Year.");
        return;
    }

    if (section === "") {
        alert("Please select Section.");
        return;
    }

    step2.style.display = "none";
    step3.style.display = "block";

    progressFill.style.width = "100%";
    progressText.innerHTML = "Step 3 of 3";

});

// ==========================================
// STEP 3 → STEP 2
// ==========================================

previous2.addEventListener("click", function () {

    step3.style.display = "none";
    step2.style.display = "block";

    progressFill.style.width = "66%";
    progressText.innerHTML = "Step 2 of 3";

});

// ==========================================
// SAVE PROFILE
// ==========================================

document.getElementById("saveProfile").addEventListener("click", function (e) {

    e.preventDefault();

    const category = document.getElementById("assessmentCategory").value;
    const language = document.getElementById("language").value;
    const difficulty = document.getElementById("difficulty").value;
    const confirm = document.getElementById("confirmDetails");

    if (category === "") {

        alert("Please select Assessment Category.");
        return;

    }

    if (language === "") {

        alert("Please select Preferred Programming Language.");
        return;

    }

    if (!confirm.checked) {

        alert("Please confirm your information.");
        return;

    }

    // Get logged-in user
    let user = JSON.parse(sessionStorage.getItem("user"));

    // Add profile details
    user.fullName = document.getElementById("fullName").value;
    user.mobile = document.getElementById("mobile").value;
    user.gender = document.getElementById("gender").value;

    user.registerNo = document.getElementById("registerNo").value;
    user.college = document.getElementById("college").value;
    user.department = document.getElementById("department").value;
    user.year = document.getElementById("year").value;
    user.section = document.getElementById("section").value;

    user.assessmentCategory = category;
    user.language = language;
    user.difficulty = difficulty;

    // Save updated user
    sessionStorage.setItem("user", JSON.stringify(user));

    alert("Profile Saved Successfully!");

    window.location.href = "dashboard.html";

});