// ==========================================
// REGISTER PAGE JAVASCRIPT
// ==========================================

const registerForm = document.getElementById("registerForm");

const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");

const strengthFill = document.getElementById("strengthFill");
const strengthText = document.getElementById("strengthText");

// ==========================================
// PASSWORD STRENGTH
// ==========================================

password.addEventListener("input", () => {

    const value = password.value;

    let strength = 0;

    if (value.length >= 8)
        strength++;

    if (/[A-Z]/.test(value))
        strength++;

    if (/[0-9]/.test(value))
        strength++;

    if (/[^A-Za-z0-9]/.test(value))
        strength++;

    switch (strength) {

        case 0:
        case 1:

            strengthFill.style.width = "25%";
            strengthFill.style.background = "#ef4444";
            strengthText.innerHTML = "Weak Password";

            break;

        case 2:

            strengthFill.style.width = "50%";
            strengthFill.style.background = "#f59e0b";
            strengthText.innerHTML = "Medium Password";

            break;

        case 3:

            strengthFill.style.width = "75%";
            strengthFill.style.background = "#3b82f6";
            strengthText.innerHTML = "Good Password";

            break;

        case 4:

            strengthFill.style.width = "100%";
            strengthFill.style.background = "#22c55e";
            strengthText.innerHTML = "Strong Password";

            break;

    }

});

// ==========================================
// FORM VALIDATION + REGISTER API
// ==========================================

registerForm.addEventListener("submit", async function (e) {

    e.preventDefault();

    const fullName = document.getElementById("fullname").value.trim();
    const email = document.getElementById("email").value.trim();
    const terms = document.getElementById("terms");

    if (fullName.length < 3) {
        alert("Please enter a valid Full Name.");
        return;
    }

    if (password.value !== confirmPassword.value) {
        alert("Passwords do not match.");
        return;
    }

    if (!terms.checked) {
        alert("Please accept Terms & Conditions.");
        return;
    }

    const user = {

        fullName: fullName,
        email: email,
        password: password.value

    };

    try {

        const response = await fetch(
            "http://localhost:8080/api/auth/register",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(user)
            }
        );

        if (response.ok) {

            const user = await response.json();

            sessionStorage.setItem("user", JSON.stringify(user));

            alert("Registration Successful!");

            window.location.href = "profile.html";

        }else {

            const error = await response.text();

            alert(error);

        }

    } catch (err) {

        alert("Unable to connect to the server.");

        console.error(err);

    }

});
// ==========================================
// SHOW / HIDE PASSWORD
// ==========================================

const togglePassword = document.getElementById("togglePassword");
const toggleConfirm = document.getElementById("toggleConfirm");

togglePassword.addEventListener("click",()=>{

    if(password.type==="password"){

        password.type="text";

        togglePassword.classList.replace("fa-eye","fa-eye-slash");

    }else{

        password.type="password";

        togglePassword.classList.replace("fa-eye-slash","fa-eye");

    }

});

toggleConfirm.addEventListener("click",()=>{

    if(confirmPassword.type==="password"){

        confirmPassword.type="text";

        toggleConfirm.classList.replace("fa-eye","fa-eye-slash");

    }else{

        confirmPassword.type="password";

        toggleConfirm.classList.replace("fa-eye-slash","fa-eye");

    }

});