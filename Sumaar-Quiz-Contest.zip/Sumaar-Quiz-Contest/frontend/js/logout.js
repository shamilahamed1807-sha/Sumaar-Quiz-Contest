function logout() {

    sessionStorage.clear();

    localStorage.removeItem("user");

    alert("Logged out successfully.");

    window.location.href = "login.html";

}