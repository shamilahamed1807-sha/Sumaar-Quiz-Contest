// ======================================
// Logged In User
// ======================================

const user = JSON.parse(sessionStorage.getItem("user"));

if (!user) {

    window.location.href = "login.html";

}

document.getElementById("studentName").innerText = user.fullName;

// ======================================
// Current Date
// ======================================

const today = new Date();

document.getElementById("liveDate").innerHTML =
today.toDateString();

const round1 = Number(sessionStorage.getItem("round1Score")) || 0;
const round2 = Number(sessionStorage.getItem("round2Score")) || 0;
const round3 = Number(sessionStorage.getItem("round3Score")) || 0;

const total = round1 + round2 + round3;
const accuracy = Math.round((total / 30) * 100);

// Assessments
document.querySelectorAll(".stat-card h2")[0].innerHTML =
(total > 0) ? "1" : "0";

// Best Score
document.querySelectorAll(".stat-card h2")[1].innerHTML =
total + "/30";

// Accuracy
document.querySelectorAll(".stat-card h2")[2].innerHTML =
accuracy + "%";

// Achievement
document.querySelectorAll(".stat-card h2")[3].innerHTML =
accuracy >= 80 ? "1" : "0";

// Progress
document.getElementById("progressValue").innerHTML =
accuracy + "%";

document.querySelector(".progress-fill").style.width =
accuracy + "%";

// Chart

const ctx=document.getElementById("progressChart");

new Chart(ctx,{

type:"doughnut",

data:{

datasets:[{

data:[0,100],

backgroundColor:[

"#3B82F6",

"#1E293B"

],

borderWidth:0

}]

},

options:{

responsive:true,

cutout:"78%",

plugins:{

legend:{

display:false

},

tooltip:{

enabled:false

}

}

}

});

// document.getElementById("logoutBtn").addEventListener("click", function(e){

//     e.preventDefault();

//     sessionStorage.removeItem("user");

//     window.location.href = "login.html";

// });
const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {
    logoutBtn.addEventListener("click", function(e){
        e.preventDefault();
        sessionStorage.removeItem("user");
        window.location.href="login.html";
    });
}