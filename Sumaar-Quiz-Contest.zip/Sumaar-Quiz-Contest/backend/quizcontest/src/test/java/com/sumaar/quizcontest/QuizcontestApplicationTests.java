package com.sumaar.quizcontest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizcontestApplicationTests {

	@Test
	void contextLoads() {
	}

}
